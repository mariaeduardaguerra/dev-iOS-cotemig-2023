//
//  ViewController.swift
//  ativ_TableView_Pág41
//
//  Created by COTEMIG on 05/04/23.
//

import UIKit


class ViewController: UIViewController {
    var items = ["josé", "maria"]

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    func tableView(_ tableView: UITableView, callForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "cell01") {
            cell.textLabel?.text = items[indexPath.row]
            return cell
        }
        else {
            let cell = UITableViewCell()
                cell.textLabel?.text = items[indexPath.row]
                return cell
        }
        
    }
}


extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(self.items[indexPath.row])
    }
}

