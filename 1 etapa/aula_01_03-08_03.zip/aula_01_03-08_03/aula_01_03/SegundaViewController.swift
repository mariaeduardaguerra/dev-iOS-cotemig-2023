//
//  SegundaViewController.swift
//  aula_01_03
//
//  Created by COTEMIG on 01/03/23.
//

import UIKit

class SegundaViewController: UIViewController
{
    
    var mensagem: String = ""
    @IBOutlet weak var lblTitulo: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        print("valor recebido: \(mensagem)")
        lblTitulo.text = mensagem
        
        // Do any additional setup after loading the view.
    }
    
    /*
    override func viewWillAppear(_ animated: Bool)
    {
        print("rodou o viewWillAppear")
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        print("rodou o viewDidAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        print("rodou o viewWillDisappear")
    }
    
    override func viewDidDisappear(_ animated: Bool)
    {
        print("rodou o viewDidDisappear")
    }
    /*

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
