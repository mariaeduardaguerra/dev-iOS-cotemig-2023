//
//  ViewController.swift
//  tableViewCustomizarCap07
//
//  Created by COTEMIG on 03/05/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

