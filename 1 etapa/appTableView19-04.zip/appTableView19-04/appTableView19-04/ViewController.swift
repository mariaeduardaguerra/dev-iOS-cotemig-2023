//
//  ViewController.swift
//  appTableView19-04
//
//  Created by COTEMIG on 19/04/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var lista: [Dados] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let item01 = Dados(descricao: "comprar leite", dataInicio: "01/04/23")
        let item02 = Dados(descricao: "comprar biscoito", dataInicio: "01/04/23")
        
        lista.append(item01)
        lista.append(item02)
        
        tableView.dataSource = self
        tableView.delegate = self

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lista.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "cell01") {
            
            let item = lista[indexPath.row]
            cell.textLabel?.text = item.descricao
            cell.detailTextLabel?.text = item.dataInicio
            
            return cell
            
        }
        
        return UITableViewCell()
        
        func tableView(_ tableView : UITableView, didSelectRowAt indexPath: IndexPath){
            
            let item = lista[indexPath.row]
            performSegue(withIdentifier: "ViewToView02", sender: item)
            
        }
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let vc = segue.destination as? SegundaViewcontroller,
               let item = sender as? Dados {
                vc.dados = item
                
            }
        }
        
    }

    struct Dados {
        var descricao: String
        var dataInicio: String
    }
    
}

