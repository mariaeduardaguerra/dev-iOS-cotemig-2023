//
//  ViewController.swift
//  aula_01_03-08_03
//
//  Created by COTEMIG on 01/03/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func ClicarNoBotao(_ sender: Any)
    {
        // print("oi mundo!")
        performSegue(withIdentifier: "GoToTela2",
        sender: "bem-vindo à tela 2.")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if let segundaView = segue.destination as?
            SegundaViewController,
           let valor = sender as? String
        {
            
            segundaView.mensagem = valor
        }
        
    }


}
