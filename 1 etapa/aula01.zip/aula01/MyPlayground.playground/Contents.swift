import UIKit

var str = "Hello, playground"
var idade:Int = 10

if idade > 18 {
    print("Maior que 18")
} else {
    print("sem valor")
}
