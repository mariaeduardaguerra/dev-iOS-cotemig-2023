import UIKit

var str = "Hello, playground"

var idade: Int? = 19

if let valor=idade, valor > 18 {
    print("Há valor maior que 18")
}else{
    print("Não há valor, ou menor de 18")
}
