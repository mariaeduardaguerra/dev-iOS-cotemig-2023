import UIKit

class ViewController: UIViewController {
    var contador:Int = 0;
    
    
    @IBOutlet weak var lblName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btnClick(_ sender: Any) {
        contador += 1
        lblName.text = "button clicked \(contador)"
    }
}

