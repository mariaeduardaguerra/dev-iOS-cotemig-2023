//
//  ViewController.swift
//  aula3
//
//  Created by COTEMIG on 27/02/23.
//

import UIKit

class ViewController: UIViewController {
    var contador: Int = 0
    
    @IBOutlet weak var labelPrincipal: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func button1(_ sender: Any) {
        contador += 1
        labelPrincipal.text = "Botao acionado \(contador)vezes"
        print("Botao acionado \(contador) vezes")
    }
}

