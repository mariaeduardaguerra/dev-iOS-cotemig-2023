//
//  ViewController.swift
//  ProjetoTOG
//
//  Created by COTEMIG on 27/02/23.
//

import UIKit

class ViewController: UIViewController {
    
    var contador: Int = 0

    @IBOutlet weak var lbltitulo: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func btnbotao(_ sender: Any) {
        
        contador += 1
        print("Botão clicado \(contador) vezes")
        lbltitulo.text = "Botão clicado \(contador) vezes"
    }
}

