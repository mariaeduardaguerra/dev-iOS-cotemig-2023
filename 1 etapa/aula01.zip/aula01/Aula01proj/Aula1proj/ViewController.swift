//
//  ViewController.swift
//  Aula1proj
//
//  Created by COTEMIG on 15/02/23.
//

import UIKit

class ViewController: UIViewController {
    var contador: Int = 0
    
    @IBOutlet weak var labelPadrao: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func botaoAcionado(_ sender: Any) {
        contador += 1
        labelPadrao.text = "clicou \(contador) vezes"
    }
    
}

 
